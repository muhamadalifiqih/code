<?php
Define("judul", "Menghitung luas lingkaran");
define("phi",3.14) ;
$r = 5;
$luas = phi * $r * $r ;
Echo judul;
echo"Luas = $luas" ;
?>
